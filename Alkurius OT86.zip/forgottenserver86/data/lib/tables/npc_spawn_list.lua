mapNpcs = {	
}
