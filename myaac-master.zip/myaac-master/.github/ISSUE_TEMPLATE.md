<!--
Please use this issue tracker only for reporting MyAAC bugs.

If you need support, please use the discord server:

- https://discord.gg/2J39Wus (we have an own channel named #my-aac there)

or use otland support boards:

- https://otland.net/forums/support.16/

-->

### Server configuration
- Operating System: 
- Web Server (+ version): 
- PHP Version: 
- Server name and version (for example: TFS 0.3): 
- MyAAC Version: 

### Client configuration (Your Computer)

- Browser: 
- Operating System: 

### Description:


### Steps To Reproduce: