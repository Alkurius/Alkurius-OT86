<?php
/**
 * german language file
 * admin.php
 *
 * @author Slawkens <slawkens@gmail.com>
 */
$locale['title'] = 'MyAAC Admin';
?>
