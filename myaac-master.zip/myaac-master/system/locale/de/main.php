<?php
/**
 * german language file
 * main.php
 *
 * @author Slawkens <slawkens@gmail.com>
 */
$locale['name']     = 'Deutsch';
$locale['lang']		= 'de';
$locale['encoding'] = 'utf-8';
$locale['direction']= 'ltr';

$locale['error404'] = 'Diese Seite konnte nicht gefunden werden.';
$locale['news'] = 'Neuesten Nachrichten';
?>