<?php
/**
 * Brazilian Portuguese language file
 * admin.php
 *
 * @author Ivens Pontes <ivenscardoso@hotmail.com>
 */
$locale['title'] = 'MyAAC Admin';
?>
