<?php
/**
 * swedish language file
 * main.php
 *
 * @author Sizaro <sizaro@live.se>
 */
$locale['name']     = 'Swedish';
$locale['lang']		= 'sv';
$locale['encoding'] = 'utf-8';
$locale['direction']= 'ltr';

$locale['error404'] = 'Sidan kunde inte hittas.';
$locale['news'] = 'Senaste nyheterna';
?>