<?php

$db->exec('DROP TABLE IF EXISTS `' . TABLE_PREFIX . 'items`;');