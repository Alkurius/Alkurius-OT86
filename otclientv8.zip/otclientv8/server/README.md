Here are tools for server

all lua scripts are made for and tested on latest tfs (1.2/1.3)

add json.lua to data/lib/core and then in core.lua add: dofile('data/lib/core/json.lua')
